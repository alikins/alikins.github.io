.. ...........................................................................
.. © Copyright IBM Corporation 2020                                          .
.. ...........................................................................

Contributing
============

Currently we are not accepting community contributions. Though, we encourage
opening `git issues`_ for bugs, comments or feature requests.

Periodically review this content to learn when and how contributions can be
made in the future.

.. _git issues:
   https://github.com/ansible-collections/ibm_zos_core/issues

Helpful Links
=============

* Getting started `Ansible guide`_.

.. _Ansible guide:
   https://docs.ansible.com/ansible/latest/user_guide/intro_getting_started.html


